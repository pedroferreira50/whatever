/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   pipex.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pviegas- <pviegas-@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/21 12:51:10 by pviegas-          #+#    #+#             */
/*   Updated: 2024/11/21 15:17:58 by pviegas-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "pipex.h"

static void	command_file_init(char **argv, t_data *data)
{
	data->cmd1_args = parse_command(argv[2]);
	data->cmd2_args = parse_command(argv[3]);
	data->input_file = argv[1];
	data->output_file = argv[4];
	data->pid1 = -1;
	data->pid2 = -1;
	data->infile_fd = -1;
	data->outfile_fd = -1;
	data->pipefd[0] = -1;
	data->pipefd[1] = -1;
}

static void	child_processes(t_data *data, int *pipefd, int flag, char **envp)
{
	if (data->pid1 == 0 && flag == 0)
	{
		close(pipefd[0]);
		data->infile_fd = open_infile(data);
		run_command(data->cmd1_args, pipefd[1], envp, data);
		close(pipefd[1]);
		close(data->infile_fd);
		exit(1);
	}
	if (data->pid2 == 0 && flag == 1)
	{
		close(pipefd[1]);
		data->outfile_fd = open_outfile(data);
		run_command2(data->cmd2_args, pipefd[0], envp, data);
		close(pipefd[0]);
		close(data->outfile_fd);
		exit(1);
	}
}

int	main(int argc, char **argv, char **envp)
{
	t_data	data;
	int		status;

	if (argc != 5)
	{
		ft_putstr_fd("Usage: ", 2);
		ft_putstr_fd("./pipex <input_file> <cmd1> <cmd2> <output_file>\n", 2);
		exit(1);
	}
	command_file_init(argv, &data);
	init_pipe(data.pipefd);
	data.pid1 = init_fork();
	child_processes(&data, data.pipefd, 0, envp);
	data.pid2 = init_fork();
	child_processes(&data, data.pipefd, 1, envp);
	close(data.pipefd[0]);
	close(data.pipefd[1]);
	waitpid(data.pid1, NULL, 0);
	waitpid(data.pid2, &status, 0);
	if (WIFEXITED(status))
		status = WEXITSTATUS(status);
	free_command_args(data.cmd1_args);
	free_command_args(data.cmd2_args);
	return (status);
}

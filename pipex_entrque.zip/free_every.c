/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   free_every.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pviegas- <pviegas-@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/21 14:34:30 by pviegas-          #+#    #+#             */
/*   Updated: 2024/11/21 14:35:32 by pviegas-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "pipex.h"

void	free_command_args(char **args)
{
	int	i;

	i = 0;
	while (args[i] != NULL)
	{
		free(args[i]);
		i++;
	}
	free(args);
}

void	cleanup_resources(t_data *data)
{
	if (data->infile_fd != -1)
		close(data->infile_fd);
	if (data->outfile_fd != -1)
		close(data->outfile_fd);
	if (data->pipefd[0] != -1)
		close(data->pipefd[0]);
	if (data->pipefd[1] != -1)
		close(data->pipefd[1]);
	if (data->cmd1_args)
		free_command_args(data->cmd1_args);
	if (data->cmd2_args)
		free_command_args(data->cmd2_args);
	data->infile_fd = -1;
	data->outfile_fd = -1;
	data->pipefd[0] = -1;
	data->pipefd[1] = -1;
	data->cmd1_args = NULL;
	data->cmd2_args = NULL;
}

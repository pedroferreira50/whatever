/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   pipex.h                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pviegas- <pviegas-@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/21 12:51:42 by pviegas-          #+#    #+#             */
/*   Updated: 2024/11/21 14:56:52 by pviegas-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef PIPEX_H
# define PIPEX_H

# include <stdlib.h>
# include <unistd.h>
# include <fcntl.h>
# include <sys/wait.h>
# include <string.h>
# include <stdbool.h>
# include <stdio.h>
# include "libft/libft.h"

typedef struct s_data
{
	char	*input_file;
	char	*output_file;
	char	**cmd1_args;
	char	**cmd2_args;
	pid_t	pid1;
	pid_t	pid2;
	int		infile_fd;
	int		outfile_fd;
	int		pipefd[2];
}	t_data;

typedef struct s_parse
{
	char		**args;
	int			args_count;
	bool		in_quotes;
	char		quote_char;
	size_t		i;
	size_t		start;
	int			brace_count;
	const char	*cmd;
}	t_parse;

void	init_pipe(int *pipefd);
pid_t	init_fork(void);
int		open_outfile(t_data *data);
int		open_infile(t_data *data);
void	free_command_args(char **args);
void	run_command(char *const *args, int outfd,
			char *const *envp, t_data *data);
void	run_command2(char *const *args, int infd,
			char *const *envp, t_data *data);
char	*find_command_path(char *command, char *const envp[]);
char	**parse_command(const char *cmd);
void	handle_end_of_quoted_string(t_parse *state);
char	**finalize_args(t_parse *state);
void	handle_non_quoted_space(t_parse *state);
void	add_argument(t_parse *state);
void	cleanup_resources(t_data *data);
#endif
/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main_utils.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pviegas- <pviegas-@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/21 12:50:58 by pviegas-          #+#    #+#             */
/*   Updated: 2024/11/21 17:59:54 by pviegas-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "pipex.h"

int	open_infile(t_data *data)
{
	int	fd;

	if (access(data->input_file, F_OK | R_OK) != 0)
	{
		if (access(data->input_file, F_OK) != 0)
			ft_putstr_fd("no such file or directory: ", STDERR_FILENO);
		else
			ft_putstr_fd("Permission denied: ", STDERR_FILENO);
		ft_putstr_fd(data->input_file, STDERR_FILENO);
		ft_putendl_fd("", STDERR_FILENO);
		cleanup_resources(data);
		exit(1);
	}
	fd = open(data->input_file, O_RDONLY);
	if (fd == -1)
	{
		perror("Error opening file");
		cleanup_resources(data);
		exit(1);
	}
	return (fd);
}

int	open_outfile(t_data *data)
{
	int	fd;

	if (access(data->output_file, F_OK) == 0)
	{
		if (access(data->output_file, W_OK) != 0)
		{
			ft_putstr_fd("Permission denied: ", STDERR_FILENO);
			ft_putstr_fd(data->output_file, STDERR_FILENO);
			ft_putendl_fd("", STDERR_FILENO);
			cleanup_resources(data);
			exit(1);
		}
	}
	fd = open(data->output_file, O_WRONLY | O_CREAT | O_TRUNC, 0664);
	if (fd == -1)
	{
		perror("Error opening file");
		cleanup_resources(data);
		exit(1);
	}
	return (fd);
}

pid_t	init_fork(void)
{
	pid_t	pid;

	pid = fork();
	if (pid == -1)
	{
		ft_putstr_fd("Error: fork failed\n", STDERR_FILENO);
		exit(1);
	}
	return (pid);
}

void	init_pipe(int *pipefd)
{
	if (pipe(pipefd) == -1)
	{
		ft_putstr_fd("Error: pipe failed\n", STDERR_FILENO);
		exit(1);
	}
}

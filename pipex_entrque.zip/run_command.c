/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   run_command.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pviegas- <pviegas-@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/21 12:51:14 by pviegas-          #+#    #+#             */
/*   Updated: 2024/11/21 15:00:16 by pviegas-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "pipex.h"

static void	dup2_and_close(int file_fd, int flag)
{
	if (file_fd > -1 && file_fd != flag)
	{
		dup2(file_fd, flag);
		close(file_fd);
	}
}

void	run_command(char *const *args, int outfd,
	char *const *envp, t_data *data)
{
	char	*cmd_path;

	if (data->infile_fd > -1)
		dup2_and_close(data->infile_fd, STDIN_FILENO);
	if (outfd > -1)
		dup2_and_close(outfd, STDOUT_FILENO);
	cmd_path = find_command_path(args[0], envp);
	if (cmd_path)
	{
		execve(cmd_path, args, envp);
		ft_putstr_fd("Error: execve failed\n", STDERR_FILENO);
		free(cmd_path);
	}
	else
	{
		if (outfd > -1)
			close(outfd);
		ft_putstr_fd("Command not found: ", 2);
		ft_putstr_fd(args[0], 2);
		ft_putendl_fd("", 2);
		cleanup_resources(data);
		exit(127);
	}
	exit(1);
}

void	run_command2(char *const *args, int infd,
	char *const *envp, t_data *data)
{
	char	*cmd_path;

	if (infd > -1)
		dup2_and_close(infd, STDIN_FILENO);
	if (data->outfile_fd > -1)
		dup2_and_close(data->outfile_fd, STDOUT_FILENO);
	cmd_path = find_command_path(args[0], envp);
	if (cmd_path)
	{
		execve(cmd_path, args, envp);
		ft_putstr_fd("Error: execve failed\n", STDERR_FILENO);
		free(cmd_path);
	}
	else
	{
		if (infd > -1)
			close(infd);
		ft_putstr_fd("Command not found: ", 2);
		ft_putstr_fd(args[0], 2);
		ft_putendl_fd("", 2);
		cleanup_resources(data);
		exit(127);
	}
	exit(1);
}

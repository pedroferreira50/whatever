/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   parse_command_utils.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pviegas- <pviegas-@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/21 12:51:02 by pviegas-          #+#    #+#             */
/*   Updated: 2024/11/21 12:51:03 by pviegas-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "pipex.h"

void	add_argument(t_parse *state)
{
	char	*arg;
	char	**new_args;
	int		i;

	arg = ft_substr(state->cmd, state->start, state->i - state->start);
	if (!arg)
	{
		ft_putstr_fd("Error: malloc failed\n", STDERR_FILENO);
		exit(1);
	}
	new_args = malloc(sizeof(char *) * (state->args_count + 2));
	if (!new_args)
	{
		ft_putstr_fd("Error: malloc failed\n", STDERR_FILENO);
		exit(1);
	}
	i = -1;
	while (i++ < state->args_count)
		new_args[i] = state->args[i];
	new_args[state->args_count] = arg;
	new_args[state->args_count + 1] = NULL;
	free(state->args);
	state->args = new_args;
	state->args_count++;
}

void	handle_non_quoted_space(t_parse *state)
{
	if (state->i > state->start)
		add_argument(state);
	while (state->cmd[state->i] == ' ')
		state->i++;
	state->start = state->i;
}

char	**finalize_args(t_parse *state)
{
	state->args[state->args_count] = NULL;
	return (state->args);
}

void	handle_end_of_quoted_string(t_parse *state)
{
	state->in_quotes = false;
	add_argument(state);
	state->i++;
	state->start = state->i;
	state->quote_char = '\0';
}

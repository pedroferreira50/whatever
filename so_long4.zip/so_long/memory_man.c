/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   memory_man.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pviegas- <pviegas-@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/15 15:01:10 by pviegas-          #+#    #+#             */
/*   Updated: 2024/11/15 15:01:11 by pviegas-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "so_long.h"

void	free_map(t_data *data)
{
	int	i;

	i = 0;
	while (i < data->map_height)
	{
		free(data->map[i]);
		i++;
	}
	free(data->map);
}

void	free_everything(t_data *data)
{
	if (data->img_player != NULL)
		mlx_destroy_image(data->mlx, data->img_player);
	if (data->img_wall != NULL)
		mlx_destroy_image(data->mlx, data->img_wall);
	if (data->img_collectible != NULL)
		mlx_destroy_image(data->mlx, data->img_collectible);
	if (data->img_exit != NULL)
		mlx_destroy_image(data->mlx, data->img_exit);
	if (data->img_space != NULL)
		mlx_destroy_image(data->mlx, data->img_space);
	if (data->map)
		free_map(data);
	if (data->win != NULL)
		mlx_destroy_window(data->mlx, data->win);
	if (data->mlx != NULL)
	{
		mlx_destroy_display(data->mlx);
		free(data->mlx);
	}
}

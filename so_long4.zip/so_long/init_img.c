/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   init_img.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pviegas- <pviegas-@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/15 15:01:30 by pviegas-          #+#    #+#             */
/*   Updated: 2024/11/15 15:01:31 by pviegas-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "so_long.h"

void	init_img_s(t_data *data)
{
	char	*wall_path;
	char	*space_path;
	char	*exit_path;
	char	*collectible_path;
	char	*player_path;

	wall_path = "images/wall_32px_0.xpm";
	data->img_wall = mlx_xpm_file_to_image(data->mlx, wall_path,
			&data->img_width, &data->img_height);
	space_path = "images/floor_32px_0.xpm";
	data->img_space = mlx_xpm_file_to_image(data->mlx, space_path,
			&data->img_width, &data->img_height);
	exit_path = "images/portal_32px_0.xpm";
	data->img_exit = mlx_xpm_file_to_image(data->mlx, exit_path,
			&data->img_width, &data->img_height);
	collectible_path = "images/coins_32px_0.xpm";
	data->img_collectible = mlx_xpm_file_to_image(data->mlx, collectible_path,
			&data->img_width, &data->img_height);
	player_path = "images/player_32px_0.xpm";
	data->img_player = mlx_xpm_file_to_image(data->mlx, player_path,
			&data->img_width, &data->img_height);
}

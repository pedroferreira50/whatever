/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   read_map2.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pviegas- <pviegas-@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/15 15:00:55 by pviegas-          #+#    #+#             */
/*   Updated: 2024/11/15 15:08:54 by pviegas-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "so_long.h"

static void	min_char(t_data *data, int fd)
{
	if (data->char_p != 1 || data->char_c < 1 || data->char_e != 1)
	{
		ft_putstr_fd("Error: Map has wrong char requiremens.\n", 2);
		close(fd);
		free_everything(data);
		exit(EXIT_FAILURE);
	}
}

void	read_and_validate_map(t_data *data, const char *map_path)
{
	int		fd;
	char	*line;
	int		y;

	y = 0;
	fd = open_file(map_path);
	line = get_next_line(fd);
	while (line != NULL)
	{
		if (process_line(data, line, y) == 0)
		{
			free(line);
			free_everything(data);
			close(fd);
			exit(EXIT_FAILURE);
		}
		free(line);
		y++;
		line = get_next_line(fd);
	}
	min_char(data, fd);
	close(fd);
}

void	allocate_map_memory(t_data *data)
{
	int	i;

	i = 0;
	data->map = malloc(data->map_height * sizeof(char *));
	while (i < data->map_height)
	{
		data->map[i] = malloc((data->map_width + 1) * sizeof(char));
		i++;
	}
}

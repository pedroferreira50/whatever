/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   read_map.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pviegas- <pviegas-@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/15 15:00:59 by pviegas-          #+#    #+#             */
/*   Updated: 2024/11/15 15:08:39 by pviegas-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "so_long.h"

static void	check_empty_map(t_data *data, int fd)
{
	if (data->map_height == 0)
	{
		ft_putstr_fd("Error: Empty map file\n", 2);
		close(fd);
		free_everything(data);
		exit(EXIT_FAILURE);
	}
}

static int	check_map_dimensions(t_data *data, int line_len, char *line)
{
	if (data->map_height == 0)
		data->map_width = line_len;
	else if (line_len != data->map_width)
	{
		ft_putstr_fd("Error: Map is not a rectangle\n", 2);
		free(line);
		return (-1);
	}
	return (0);
}

static void	calculate_map_dimensions(t_data *data, int fd)
{
	char	*line;
	int		line_len;

	line = get_next_line(fd);
	while (line != NULL)
	{
		line_len = process_line_nl(line);
		if (line_len == -1)
		{
			close(fd);
			free_everything(data);
			exit(EXIT_FAILURE);
		}
		if (check_map_dimensions(data, line_len, line) == -1)
		{
			close(fd);
			free_everything(data);
			exit(EXIT_FAILURE);
		}
		data->map_height++;
		free(line);
		line = get_next_line(fd);
	}
	check_empty_map(data, fd);
	close(fd);
}

void	read_map(t_data *data, const char *map_path)
{
	int	fd;

	fd = open_file(map_path);
	if (fd == -1)
	{
		ft_putstr_fd("Error opening .ber file", 2);
		free_everything(data);
		exit(EXIT_FAILURE);
	}
	calculate_map_dimensions(data, fd);
	allocate_map_memory(data);
	read_and_validate_map(data, map_path);
	check_map_completable(data);
}

/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   so_long.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pviegas- <pviegas-@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/15 15:00:48 by pviegas-          #+#    #+#             */
/*   Updated: 2024/11/15 15:09:49 by pviegas-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "so_long.h"

//update_map(data);
int	render_next_frame(t_data *data)
{
	draw_map(data);
	return (0);
}

static void	init_data(t_data *data)
{
	data->mlx = NULL;
	data->win = NULL;
	data->img_wall = NULL;
	data->img_space = NULL;
	data->img_player = NULL;
	data->img_collectible = NULL;
	data->img_exit = NULL;
	data->map = NULL;
	data->img_width = 0;
	data->img_height = 0;
	data->map_width = 0;
	data->map_height = 0;
	data->player_x = 0;
	data->player_y = 0;
	data->collectibles_count = 0;
	data->exit_x = 0;
	data->exit_y = 0;
	data->pressed = 0;
	data->prev_player_y = 0;
	data->prev_player_x = 0;
	data->char_c = 0;
	data->char_p = 0;
	data->char_e = 0;
	data->ready = 0;
}

//mlx_hook(data->win, 02, 1L<<0, key_press, data);
static void	mlx_main(t_data *data)
{
	data->win = mlx_new_window(data->mlx, data->map_width * data->img_width,
			data->map_height * data->img_height, "Map Display");
	if (data->win == NULL)
	{
		ft_putstr_fd("Failed to create a new window\n", 2);
		free_everything(data);
		exit(EXIT_FAILURE);
	}
	draw_map(data);
	mlx_key_hook(data->win, key_press, data);
	mlx_loop_hook(data->mlx, render_next_frame, data);
	mlx_hook(data->win, 17, 0, close_window, data);
	mlx_loop(data->mlx);
}

int	main(int argc, char **argv)
{
	t_data	data;
	char	*map_path;

	check_arguments(argc, argv);
	map_path = argv[1];
	init_data(&data);
	data.mlx = mlx_init();
	if (data.mlx == NULL)
	{
		ft_putstr_fd("Failed to initialize mlx\n", 2);
		return (EXIT_FAILURE);
	}
	read_map(&data, map_path);
	init_img_s(&data);
	if (data.img_wall == NULL || data.img_space == NULL
		|| data.img_exit == NULL)
	{
		ft_putstr_fd("Failed to load images\n", 2);
		free_everything(&data);
		return (EXIT_FAILURE);
	}
	mlx_main(&data);
	free_everything(&data);
	return (0);
}

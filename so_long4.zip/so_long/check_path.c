/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   check_path.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pviegas- <pviegas-@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/15 15:01:37 by pviegas-          #+#    #+#             */
/*   Updated: 2024/11/15 15:25:01 by pviegas-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "so_long.h"

static int	ft_strcmp(const char *s1, const char *s2)
{
	if (*s1 && *s2)
	{
		if (*s1 != *s2)
			return (*s1 - *s2);
		s1++;
		s2++;
	}
	return (*s1 - *s2);
}

static int	is_ber_file(const char *filename)
{
	int	len;
	int	fd;

	len = ft_strlen(filename);
	if (len > 4 && ft_strcmp(filename + len - 4, ".ber") != 0)
	{
		ft_putstr_fd("Error: File must have a .ber extension.\n", 2);
		return (1);
	}
	fd = open(filename, O_RDONLY);
	if (fd == -1)
	{
		ft_putstr_fd("Error: The file does not exist\n", 2);
		return (1);
	}
	close(fd);
	return (0);
}

void	check_arguments(int argc, char **argv)
{
	if (argc < 2)
	{
		ft_putstr_fd("Error: No file provided.\n", 2);
		exit(EXIT_FAILURE);
	}
	else if (argc > 2)
	{
		ft_putstr_fd("Error: Too many arguments.\n", 2);
		exit(EXIT_FAILURE);
	}
	else if (is_ber_file(argv[1]))
		exit(EXIT_FAILURE);
}

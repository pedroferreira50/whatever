/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   map_completable.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pviegas- <pviegas-@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/15 15:01:19 by pviegas-          #+#    #+#             */
/*   Updated: 2024/11/15 15:06:48 by pviegas-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "so_long.h"

static void	free_visited(int **visited, int map_height)
{
	int	i;

	i = 0;
	while (i < map_height)
	{
		free(visited[i]);
		i++;
	}
	free(visited);
}

static void	check_reachability(t_data *data, int **visited)
{
	int	y;
	int	x;

	y = 0;
	while (y < data->map_height)
	{
		x = 0;
		while (x < data->map_width)
		{
			if ((data->map[y][x] == 'C'
				|| data->map[y][x] == 'E') && !visited[y][x])
			{
				ft_putstr_fd("Error: Map is not completable\n", 2);
				free_visited(visited, data->map_height);
				free_everything(data);
				exit(EXIT_FAILURE);
			}
			x++;
		}
		y++;
	}
}

static int	is_reachable(t_data *data, int x, int y, int **visited)
{
	int	dx[4];
	int	dy[4];
	int	i;

	dx[0] = 1;
	dx[1] = -1;
	dx[2] = 0;
	dx[3] = 0;
	dy[0] = 0;
	dy[1] = 0;
	dy[2] = 1;
	dy[3] = -1;
	if (x < 0 || x >= data->map_width || y < 0 || y >= data->map_height
		|| visited[y][x] || data->map[y][x] == '1' || data->map[y][x] == 'X')
		return (0);
	visited[y][x] = 1;
	i = 0;
	while (i < 4)
	{
		is_reachable(data, x + dx[i], y + dy[i], visited);
		i++;
	}
	return (1);
}

static int	**allocate_visited(int map_width, int map_height)
{
	int	**visited;
	int	i;

	i = 0;
	visited = malloc(map_height * sizeof(int *));
	while (i < map_height)
	{
		visited[i] = malloc(map_width * sizeof(int));
		ft_memset(visited[i], 0, map_width * sizeof(int));
		i++;
	}
	return (visited);
}

void	check_map_completable(t_data *data)
{
	int	**visited;

	visited = allocate_visited(data->map_width, data->map_height);
	is_reachable(data, data->player_x, data->player_y, visited);
	check_reachability(data, visited);
	free_visited(visited, data->map_height);
}

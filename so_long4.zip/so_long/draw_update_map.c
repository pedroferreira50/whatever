/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   draw_update_map.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pviegas- <pviegas-@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/15 15:01:33 by pviegas-          #+#    #+#             */
/*   Updated: 2024/11/15 15:05:07 by pviegas-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "so_long.h"

static void	draw_map_loop(int x, int y, t_data *data)
{
	if (data->player_x == x && data->player_y == y)
		return ;
	else if (data->map[y][x] == '1')
		mlx_put_image_to_window(data->mlx, data->win, data->img_wall,
			x * data->img_width, y * data->img_height);
	else if (data->map[y][x] == '0')
		mlx_put_image_to_window(data->mlx, data->win, data->img_space,
			x * data->img_width, y * data->img_height);
	else if (data->map[y][x] == 'C')
		mlx_put_image_to_window(data->mlx, data->win, data->img_collectible,
			x * data->img_width, y * data->img_height);
	else if (data->map[y][x] == 'E')
		mlx_put_image_to_window(data->mlx, data->win, data->img_exit,
			x * data->img_width, y * data->img_height);
}

void	draw_map(t_data *data)
{
	int	y;
	int	x;

	y = 0;
	while (y < data->map_height)
	{
		x = 0;
		while (x < data->map_width)
		{
			draw_map_loop(x, y, data);
			x++;
		}
		y++;
	}
	mlx_put_image_to_window(data->mlx, data->win, data->img_player,
		data->player_x * data->img_width, data->player_y * data->img_height);
}

int	check_win_condition(t_data *data)
{
	if (data->collectibles_count <= 0
		&& data->map[data->player_y][data->player_x] == 'E')
		return (1);
	return (0);
}

int	close_window(t_data *data)
{
	free_everything(data);
	exit(0);
	return (0);
}

/* void	update_map(t_data *data)
{
		if (data->prev_player_x != 0)
		{
			if (data->map[data->prev_player_y][data->prev_player_x] == 'E')
			{
				mlx_put_image_to_window(data->mlx, data->win, data->img_exit,
					data->prev_player_x * data->img_width,
					data->prev_player_y * data->img_height);
			}
			else
			{
				mlx_put_image_to_window(data->mlx, data->win, data->img_space,
					data->prev_player_x * data->img_width,
					data->prev_player_y * data->img_height);
			}
		}
		mlx_put_image_to_window(data->mlx, data->win, data->img_player,
			data->player_x * data->img_width, data->player_y * data->img_height);
	data->ready = 0;
} */

/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   read_map_utils.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pviegas- <pviegas-@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/15 15:01:06 by pviegas-          #+#    #+#             */
/*   Updated: 2024/11/15 15:07:39 by pviegas-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "so_long.h"

static void	handle_special_chars(t_data *data, char c, int y, int x)
{
	if (c == 'P')
	{
		data->player_x = x;
		data->player_y = y;
		data->char_p++;
	}
	else if (c == 'C')
	{
		data->collectibles_count++;
		data->char_c++;
	}
	else if (c == 'E')
	{
		data->exit_x = x;
		data->exit_y = y;
		data->char_e++;
	}
}

static int	validate_map_char(t_data *data, int y, int x)
{
	char	c;

	c = data->map[y][x];
	if (c != '1' && c != '0' && c != 'P' && c != 'C' && c != 'E' && c != 'X')
	{
		ft_putstr_fd("Error: Invalid character in map file\n", 2);
		return (-1);
	}
	if ((x == 0 || x == data->map_width - 1) && c != '1')
	{
		ft_putstr_fd("Error: Line does not start or end with '1'\n", 2);
		return (-1);
	}
	if ((y == 0 || y == data->map_height - 1) && c != '1')
	{
		ft_putstr_fd("Error: First/last line is not composed of '1's\n", 2);
		return (-1);
	}
	handle_special_chars(data, c, y, x);
	return (0);
}

int	process_line(t_data *data, char *line, int y)
{
	int	line_len;
	int	x;

	line_len = ft_strlen(line);
	if (line[line_len - 1] == '\n')
		line_len--;
	if (line_len != data->map_width)
	{
		ft_putstr_fd("Error: Line length does not match map width\n", 2);
		return (0);
	}
	x = 0;
	while (x < data->map_width)
	{
		data->map[y][x] = line[x];
		if (validate_map_char(data, y, x) == -1)
			return (0);
		x++;
	}
	data->map[y][data->map_width] = '\0';
	return (1);
}

int	open_file(const char *map_path)
{
	int	fd;

	fd = open(map_path, O_RDONLY);
	return (fd);
}

int	process_line_nl(char *line)
{
	int	line_len;

	line_len = ft_strlen(line);
	if (line[line_len - 1] == '\n')
	{
		line[line_len - 1] = '\0';
		line_len--;
	}
	if (line_len == 0)
	{
		ft_putstr_fd("Error: Empty line in map file\n", 2);
		free(line);
		return (-1);
	}
	return (line_len);
}

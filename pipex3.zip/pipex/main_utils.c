#include "pipex.h"

int	open_infile(t_data *data)
{
	int	fd;

	fd = open(data->input_file, O_RDONLY);
	if (fd == -1)
	{
		perror("Error opening file");
		exit(1);
	}
	return (fd);
}

int	open_outfile(t_data *data)
{
	int	fd;

	fd = open(data->output_file, O_WRONLY | O_CREAT | O_TRUNC, 0664);
	if (fd == -1)
	{
		ft_putstr_fd("Error: open output file failed\n", STDERR_FILENO);
		exit(1);
	}
	return (fd);
}

pid_t	init_fork(void)
{
	pid_t	pid;

	pid = fork();
	if (pid == -1)
	{
		ft_putstr_fd("Error: fork failed\n", STDERR_FILENO);
		exit(1);
	}
	return (pid);
}

void	init_pipe(int *pipefd)
{
	if (pipe(pipefd) == -1)
	{
		ft_putstr_fd("Error: pipe failed\n", STDERR_FILENO);
		exit(1);
	}
}

void	free_command_args(char **args)
{
	int	i;

	i = 0;
	while (args[i] != NULL)
	{
		free(args[i]);
		i++;
	}
	free(args);
}

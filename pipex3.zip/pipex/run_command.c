#include "pipex.h"

static void	dup2_and_close(int file_fd, int flag)
{
	if (file_fd > -1 && file_fd != flag)
	{
		dup2(file_fd, flag);
		close(file_fd);
	}
}

void	run_command(char *const *args, int infd, int outfd, char *const *envp)
{
	char	*cmd_path;

	if (infd > -1)
		dup2_and_close(infd, STDIN_FILENO);
	if (outfd > -1)
		dup2_and_close(outfd, STDOUT_FILENO);
	cmd_path = find_command_path(args[0], envp);
	if (cmd_path)
	{
		execve(cmd_path, args, envp);
		ft_putstr_fd("Error: execve failed\n", STDERR_FILENO);
		free(cmd_path);
	}
	else
	{
		if (infd > -1)
			close(infd);
		if (outfd > -1)
			close(outfd);
		ft_putstr_fd("Command not found: ", 2);
		ft_putstr_fd(args[0], 2);
		ft_putendl_fd("", 2);
		exit(127);
	}
	exit(1);
}

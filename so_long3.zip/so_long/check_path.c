#include "so_long.h"

int	is_ber_file(const char *filename)
{
	int	len;
	int	fd;

	len = strlen(filename); //remove
	if (len > 4 && strcmp(filename + len - 4, ".ber") != 0) //remove
	{
		ft_printf("Error: File must have a .ber extension.\n"); //remove
		return (1);
	}
	ft_printf("%s\n", filename); //remove
	fd = open(filename, O_RDONLY);
	if (fd == -1)
	{
		ft_printf("The file does not exist\n"); //remove
		close(fd);
		return (1);
	}
	close(fd);
	return (0);
}

void	check_arguments(int argc, char **argv)
{
	if (argc < 2)
	{
		ft_printf("Error: No file provided. Usage: ./program <map.ber>\n"); //remove
		exit(EXIT_FAILURE);
	}
	else if (argc > 2)
	{
		ft_printf("Error: Too many arguments. Usage: ./program <map.ber>\n"); //remove
		exit(EXIT_FAILURE);
	}
	else if (is_ber_file(argv[1]))
		exit(EXIT_FAILURE);
	ft_printf("File %s is valid.\n", argv[1]); //remove
}

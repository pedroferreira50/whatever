#ifndef SO_LONG_H
# define SO_LONG_H

# include "minilibx-linux/mlx.h"
# include "libft/libft.h"
# include <stdlib.h>
# include <string.h>
# include <stdio.h>
# include <fcntl.h>

typedef struct s_data
{
	void	*mlx;
	void	*win;
	void	*img_wall;
	void	*img_space;
	void	*img_player;
	void	*img_collectible;
	void	*img_exit;
	int		img_width;
	int		img_height;
	char	**map;
	int		map_width;
	int		map_height;
	int		player_x;
	int		player_y;
	int		collectibles_count;
	int		exit_x;
	int		exit_y;
	int		pressed;
	int		prev_player_y;
	int		prev_player_x;
	int		char_p;
	int		char_c;
	int		char_e;
	int		ready;
}	t_data;

void	check_arguments(int argc, char **argv);
void	init_img_s(t_data *data);
int		close_window(t_data *data);
int		key_press(int keycode, t_data *data);
void	free_map(t_data *data);
void	update_map(t_data *data);
void	read_map(t_data *data, const char *map_path);
void	free_everything(t_data *data);
void	draw_map(t_data *data);
int		process_line_nl(char *line);
int		open_file(const char *map_path);
void	check_map_completable(t_data *data);
void	allocate_map_memory(t_data *data);
void	read_and_validate_map(t_data *data, const char *map_path);
int		process_line(t_data *data, char *line, int y);
void	check_initialization(t_data *data);
int		check_win_condition(t_data *data);
int		render_next_frame(t_data *data);

#endif

#include "so_long.h"

void	min_char(t_data *data, int fd)
{
	if (data->char_p != 1 || data->char_c < 1 || data->char_e != 1)
	{
		ft_printf("Error: Map doesn't meet the minimum char requiremens.\n"); //remove
		close(fd);
		free_everything(data);
		exit(EXIT_FAILURE);
	}
}

void	read_and_validate_map(t_data *data, const char *map_path)
{
	int		fd;
	char	*line;
	int		y;

	y = 0;
	fd = open_file(map_path);
	line = get_next_line(fd);
	while (line != NULL)
	{
		if (process_line(data, line, y) == 0)
		{
			free(line);
			free_everything(data);
			close(fd);
			exit(EXIT_FAILURE);
		}
		free(line);
		y++;
		line = get_next_line(fd);
	}
	min_char(data, fd);
	close(fd);
}

void	allocate_map_memory(t_data *data)
{
	int	i;

	i = 0;
	data->map = malloc(data->map_height * sizeof(char *));
	while (i < data->map_height)
	{
		data->map[i] = malloc((data->map_width + 1) * sizeof(char));
		i++;
	}
}

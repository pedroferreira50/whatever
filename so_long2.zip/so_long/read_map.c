#include "so_long.h"

void	check_empty_map(t_data *data, int fd)
{
	if (data->map_height == 0)
	{
		ft_printf("Error: Empty map file\n"); //remove
		close(fd);
		free_everything(data);
		exit(EXIT_FAILURE);
	}
}

int	check_map_dimensions(t_data *data, int line_len, char *line)
{
	if (data->map_height == 0)
		data->map_width = line_len;
	else if (line_len != data->map_width)
	{
		ft_printf("Error: Map is not a rectangle\n"); //remove
		free(line);
		return (-1);
	}
	return (0);
}

void	calculate_map_dimensions(t_data *data, int fd)
{
	char	*line;
	int		line_len;

	line = get_next_line(fd);
	while (line != NULL)
	{
		line_len = process_line_nl(line);
		if (line_len == -1)
		{
			close(fd);
			free_everything(data);
			exit(EXIT_FAILURE);
		}
		if (check_map_dimensions(data, line_len, line) == -1)
		{
			close(fd);
			free_everything(data);
			exit(EXIT_FAILURE);
		}
		data->map_height++;
		free(line);
		line = get_next_line(fd);
	}
	check_empty_map(data, fd);
	close(fd);
}

void	read_map(t_data *data, const char *map_path)
{
	int	fd;

	fd = open_file(map_path);
	if (fd == -1)
	{
		perror("Error opening .ber file");
		free_everything(data);
		exit(EXIT_FAILURE);
	}
	calculate_map_dimensions(data, fd);
	allocate_map_memory(data);
	read_and_validate_map(data, map_path);
	check_map_completable(data);
}

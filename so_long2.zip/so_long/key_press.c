#include "so_long.h"

int	move_left(t_data *data)
{
	int	prev_x;
	int	prev_y;

	prev_x = data->player_x;
	prev_y = data->player_y;
	if (data->player_x > 0
		&& data->map[data->player_y][data->player_x - 1] != '1')
	{
		if (data->map[data->player_y][data->player_x - 1] == 'C')
			data->collectibles_count--;
		/* else if (data->map[data->player_y][data->player_x - 1]
			== 'E' && data->collectibles_count > 0)
			return (0); */
		if (data->map[data->player_y][data->player_x] != 'E')
			data->map[data->player_y][data->player_x] = '0';// this line actually changes what the tiles are, if removed the images are still changed but internally still count as before
		data->player_x--;
		data->pressed++;
		ft_printf("Moves made: %d\n", data->pressed); //remove
		ft_printf("\033[F");
		data->prev_player_x = prev_x;
		data->prev_player_y = prev_y;
	}
	return (1);
}

int	move_right(t_data *data)
{
	int	prev_x;
	int	prev_y;

	prev_x = data->player_x;
	prev_y = data->player_y;
	if (data->player_x < data->map_width - 1
		&& data->map[data->player_y][data->player_x + 1] != '1')
	{
		if (data->map[data->player_y][data->player_x + 1] == 'C')
			data->collectibles_count--;
		/* else if (data->map[data->player_y][data->player_x + 1]
			== 'E' && data->collectibles_count > 0)
			return (0); */
		if (data->map[data->player_y][data->player_x] != 'E')
			data->map[data->player_y][data->player_x] = '0';
		data->player_x++;
		data->pressed++;
		ft_printf("\rMoves made: %d\n", data->pressed); //remove
		ft_printf("\033[F");
		data->prev_player_x = prev_x;
		data->prev_player_y = prev_y;
	}
	return (1);
}

int	move_up(t_data *data)
{
	int	prev_x;
	int	prev_y;

	prev_x = data->player_x;
	prev_y = data->player_y;
	if (data->player_y > 0
		&& data->map[data->player_y - 1][data->player_x] != '1')
	{
		if (data->map[data->player_y - 1][data->player_x] == 'C')
			data->collectibles_count--;
		/* else if (data->map[data->player_y - 1][data->player_x]
			== 'E' && data->collectibles_count > 0)
			return (0); */
		if (data->map[data->player_y][data->player_x] != 'E')
			data->map[data->player_y][data->player_x] = '0';
		data->player_y--;
		data->pressed++;
		ft_printf("Moves made: %d\n", data->pressed); //remove
		ft_printf("\033[F");
		data->prev_player_x = prev_x;
		data->prev_player_y = prev_y;
	}
	return (1);
}

int	move_down(t_data *data)
{
	int	prev_x;
	int	prev_y;

	prev_x = data->player_x;
	prev_y = data->player_y;
	if (data->player_y < data->map_height - 1
		&& data->map[data->player_y + 1][data->player_x] != '1')
	{
		if (data->map[data->player_y + 1][data->player_x] == 'C')
			data->collectibles_count--;
		/* else if (data->map[data->player_y + 1][data->player_x]
			== 'E' && data->collectibles_count > 0)
			return (0); */
		if (data->map[data->player_y][data->player_x] != 'E')
			data->map[data->player_y][data->player_x] = '0';
		data->player_y++;
		data->pressed++;
		ft_printf("Moves made: %d\n", data->pressed); //remove
		ft_printf("\033[F");
		data->prev_player_x = prev_x;
		data->prev_player_y = prev_y;
	}
	return (1);
}

int	key_press(int keycode, t_data *data)
{
	if (keycode == 65307)
		close_window(data);
	else if (keycode == 65361)
		move_left(data);
	else if (keycode == 65363)
		move_right(data);
	else if (keycode == 65362)
		move_up(data);
	else if (keycode == 65364)
		move_down(data);
	if (check_win_condition(data))
	{
		ft_printf("Congratulations! You've reached the exit.\n"); //remove
		close_window(data);
	}
	return (0);
}

#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/wait.h>
#include <string.h>
#include "libft/libft.h"

char **parse_command(const char *cmd)
{
	char **args;

	args = ft_split(cmd, ' ');
	if (!args)
	{
		ft_putstr_fd("Error: ft_split failed\n", STDERR_FILENO);
		exit(1);
	}
	return args;
}

void free_command_args(char **args)
{
	int i;

	i = 0;
	while (args[i] != NULL)
	{
		free(args[i]);
		i++;
	}
	free(args);
}

char *find_command_path(char *command, char *const envp[])
{
	char *path;
	char *path_copy;
	char *dir;
	char *full_path = NULL;
	char *temp;
	int i;

	path = NULL;
	i = 0;
	while (envp[i])
	{
		if (ft_strncmp(envp[i], "PATH=", 5) == 0)
		{
			path = envp[i] + 5;
			break;
		}
		i++;
	}
	if (!path)
	{
		if (access(command, X_OK) == 0)
			return(command);
		return NULL;
	}
	path_copy = ft_strdup(path);
	if (!path_copy)
	{
		ft_putstr_fd("Error: strdup failed\n", STDERR_FILENO);
		exit(1);
	}
	dir = strtok(path_copy, ":");
	while (dir != NULL)
	{
		if (full_path)
			free(full_path);
		full_path = ft_strjoin(dir, "/");
		if (!full_path)
		{
			ft_putstr_fd("Error: malloc failed\n", STDERR_FILENO);
			free(path_copy);
			exit(1);
		}
		temp = ft_strjoin(full_path, command);
		free(full_path);
		if (!temp)
		{
			ft_putstr_fd("Error: malloc failed\n", STDERR_FILENO);
			free(path_copy);
			exit(1);
		}
		full_path = temp;
		if (access(full_path, X_OK) == 0)
		{
			free(path_copy);
			return full_path;
		}
		dir = strtok(NULL, ":");
	}
	if (access(command, X_OK) == 0)
		return(command);
	free(path_copy);
	free(full_path);
	return NULL;
}

void run_command(char *const args[], int input_fd, int output_fd, char *const envp[])
{
	char *cmd_path;

	if (input_fd > -1 && input_fd != STDIN_FILENO)
	{
		dup2(input_fd, STDIN_FILENO);
		close(input_fd);
	}
	if (output_fd > -1 && input_fd != STDOUT_FILENO)
	{
		dup2(output_fd, STDOUT_FILENO);
		close(output_fd);
	}
	cmd_path = find_command_path(args[0], envp);
	if (cmd_path)
	{
		execve(cmd_path, args, envp);
		ft_putstr_fd("Error: execve failed\n", STDERR_FILENO);
		free(cmd_path);
	}
	else
	{
		close(input_fd);
		close(output_fd);
		ft_putstr_fd("Command not found:PEDRO ", 2);
		ft_putstr_fd(args[0], 2);
		ft_putendl_fd("", 2);
		exit(127);
	}
	exit(1);
}

int main(int argc, char **argv, char **envp)
{
	char **cmd1_args;
	char **cmd2_args;
	char *input_file;
	char *output_file;
	int	status;
	int pipefd[2];
	int infile_fd;
	int outfile_fd;
	pid_t pid1;
	pid_t pid2;

	if (argc != 5)
	{
		ft_putstr_fd("Usage: ./pipex <input_file> <cmd1> <cmd2> <output_file>\n", STDERR_FILENO);
		exit(1);
	}
	cmd1_args = parse_command(argv[2]);
	cmd2_args = parse_command(argv[3]);
	input_file = argv[1];
	output_file = argv[4];
	if (pipe(pipefd) == -1)
	{
		ft_putstr_fd("Error: pipe failed\n", STDERR_FILENO);
		exit(1);
	}
	pid1 = fork();
	if (pid1 == -1)
	{
		ft_putstr_fd("Error: fork failed\n", STDERR_FILENO);
		exit(1);
	}
	if (pid1 == 0)
	{
		close(pipefd[0]);
		infile_fd = open(input_file, O_RDONLY);
		if (infile_fd == -1)
		{
			ft_putstr_fd("Error: open input file failed\n", STDERR_FILENO);
			exit(1);
		}
		run_command(cmd1_args, infile_fd, pipefd[1], envp);
		close(infile_fd);
		exit(1);
	}
	pid2 = fork();
	if (pid2 == -1)
	{
		ft_putstr_fd("Error: fork failed\n", STDERR_FILENO);
		exit(1);
	}

	if (pid2 == 0)
	{
		close(pipefd[1]);
		outfile_fd = open(output_file, O_WRONLY | O_CREAT | O_TRUNC, 0644);
		if (outfile_fd == -1)
		{
			ft_putstr_fd("Error: open output file failed\n", STDERR_FILENO);
			exit(1);
		}
		run_command(cmd2_args, pipefd[0], outfile_fd, envp);
		close(outfile_fd);
		exit(1);
	}
	close(pipefd[0]);
	close(pipefd[1]);
	waitpid(pid1, &status, 0);
	waitpid(pid2, &status, 0);
	if (WIFEXITED(status))
		status = WEXITSTATUS(status);
	free_command_args(cmd1_args);
	free_command_args(cmd2_args);
	return (status);
}
